# Luvano Auto — Java + HTML booking demo

## Requirements
- Java 17+
- Maven 3.8+

## Run locally
From this folder:

```bash
mvn spring-boot:run
```

Open http://localhost:8080 in a browser. The HTML/CSS/JavaScript frontend is served by the Java Spring Boot app.

## Included
- Existing Luvano Auto HTML page and PhonePe QR / UPI details
- Java REST endpoint `POST /api/bookings` which records booking/payment claims
- `GET /api/bookings` demo listing endpoint
- Booking ID returned and included in the WhatsApp message

## Important limitations
- This is a starter/demo implementation. Booking records are held in memory and disappear when the server restarts. Do not use it for production customer data without adding a database, authentication, HTTPS, validation, privacy controls and backups.
- PhonePe UPI QR / UPI intent does **not** verify payment to this server. A customer-entered UTR is unverified and is explicitly marked as such. Check the credit in your bank/UPI app before confirming a booking.
- The WhatsApp message opens as a prefilled customer-side message. It is not an automatic server-to-owner WhatsApp notification. For that, integrate the official WhatsApp Business Platform with approved credentials and opt-in handling.
- Do not expose bank credentials, API secrets, or private tokens in HTML/JavaScript.
