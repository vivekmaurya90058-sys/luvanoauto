package luv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@SpringBootApplication
public class LuvanoAutoApplication {
  public static void main(String[] args) { SpringApplication.run(LuvanoAutoApplication.class, args); }
}

@RestController
@RequestMapping("/api")
class BookingController {
  private final Map<String, Map<String,Object>> bookings = new ConcurrentHashMap<>();

  @PostMapping("/bookings")
  public Map<String,Object> create(@RequestBody Map<String,Object> input) {
    String[] required = {"name","mobile","location","category","carDetails","duration","time","startDate","total","utr"};
    for (String key : required) {
      Object value = input.get(key);
      if (value == null || value.toString().isBlank()) throw new IllegalArgumentException("Missing field: " + key);
    }
    String id = "LA-" + UUID.randomUUID().toString().substring(0,8).toUpperCase(Locale.ROOT);
    Map<String,Object> record = new LinkedHashMap<>(input);
    record.put("bookingId", id);
    record.put("receivedAt", Instant.now().toString());
    record.put("paymentStatus", "CUSTOMER_REPORTED_PAID_UNVERIFIED");
    record.put("bookingStatus", "PENDING_OWNER_CONFIRMATION");
    bookings.put(id, record);
    return Map.of("bookingId", id, "paymentStatus", "UNVERIFIED", "bookingStatus", "PENDING_OWNER_CONFIRMATION");
  }

  // Demo-only endpoint: data is held in memory and is lost when the app restarts.
  @GetMapping("/bookings")
  public Collection<Map<String,Object>> list() { return bookings.values(); }
}
